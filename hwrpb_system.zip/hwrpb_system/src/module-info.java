module hwrpb_system {
	requires java.desktop;
}