package com.hwrpb_system.controller;

import java.awt.Font;
import java.io.IOException;
import java.util.ArrayList;

public class Container {
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * "Container" Klasse
	 * dient zur speicherung, Verarbeitung und Abruf von Daten die auf den Benutzer bezogen sind
	 * diese Klasse arbeitet klassen�bergreifend
	 */
	
	
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * hier werden folgende Informationen abgespeichert: Benutername, Passwort, Token
	 * kann ins unendliche erweitert werden
	 */
	static String[] user = {"markus", "schaal123", "2000",
							"kaan", "12345", "5000",
							"natasza", "Hamster1", "1420",
							"furkan", "passwort5", "3600",
							"nurdan", "Mond1900", "100"};
	
	
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * tempor�re Speicher
	 */
	static String correct_password = ""; //Passwort f�r entsprechenden, angegebenen Benutzernamen
	static ArrayList<String> only_usernames = new ArrayList<String>(); //ausslie�lich Benutzernamen
	static String selected_user = ""; //um einen Benutzer f�r beliebige Funktionen auszuw�hlen
	static String current_user = ""; //Benutzer der gerade angemeldet ist
	boolean userThere = false; //wenn "true" dann existiert Benutzer und somit kann dieser nicht hinzugef�gt werden
	
	
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * Imports von Klassen Methoden etc. zum abrufen
	 */
	Printer printer_class = new Printer();
	
	
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * "Container" management
	 */
	public Container() throws IOException {
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * Generelle Informationen f�r Konsolenausgabe
		 */
		printer_class.printLog(com.hwrpb_system.controller.Container.class + " startet...");
	}
	
	
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * klassen�bergreifende Schriftart Einstellung
	 * diese Schriftart wird �berall verwendet
	 */
	public Font getFontTypeA() {
		return new Font("Arial", Font.PLAIN, 16);
	}
	public Font getFontTypeB() {
		return new Font("Calibri", Font.BOLD, 30);
	}
	public Font getFontTypeC() {
		return new Font("Calibri", Font.BOLD, 18);
	}
	
	
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * dient zum abrufen aller Benutzernamen
	 * alle Benutzer werden aus der "user" Array abgelesen und der "only_usernames" Arrayliste hinzugef�gt
	 * 
	 * Funktionsweise:
	 * 		1. Schleife l�uft so oft durch wie Benutzer exisitieren (jeweils drei Objekte pro Benutzer)
	 * 		2. "counter" geht immer um drei hoch damit immer die dritte Position (also der Benutzername) ausgew�hlt werden
	 */
	public ArrayList<String> getUsers() {
		only_usernames.clear(); //l�scht die gesamte Arrayliste so das wenn "getUsers" abgerufen wird die Arrayliste nicht wieder um das gleiche erweitert wird
		
		int counter = 0; //"counter" wird beim weiteren durchlauf auf Null gesetzt
		for (int i = 0; i < user.length / 3; i++) { //durch drei weil drei objekte immmer ein Benutzer sind
			only_usernames.add(user[counter]); //f�gt die Benutzernamen in die "only_usernames_list" Arrayliste ein
			
			counter += 3; //0, 3, 6, 9, 12, 15...'te Position
		}
		
		return only_usernames; //gibt die Benutzernamen Arrayliste aus
	}
	
	
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * Benutzer wird zugewiesen und das dazugeh�rige Passwort wird in "correct_password" abgespeichert
	 * andere Klassen k�nnen somit Benutzernamen zur Kontrolle einschicken und �ber "getUserPassword" abrufen
	 * 
	 * Funktionsweise:
	 * 		1. Schleife l�uft so oft durch wie Benutzer exisitieren (jeweils drei Objekte pro Benutzer)
	 * 		2. "counter" geht immer um drei hoch damit immer die dritte Position (also der Benutzername) ausgew�hlt werden
	 * 		3. es wird nachgesehen an welcher Position der Benutzer im Array "user" ist
	 * 		3. wenn gefunden geht er eine Stelle weiter und gibt das Passwort zur�ck, dieses wird in "correct_password" abgespeichert
	 */
	public void setUser(String cu) { //schaut nach welcher Benutzer gerade in der ComboBox gew�hlt wurde und schickt das passende Passwort zur�ck
		int counter = 0;  //"counter" wird beim weiteren durchlauf auf Null gesetzt
		for (int i = 0; i < user.length / 3; i++) { //durch drei weil drei objekte immmer ein Benutzer sind
			if (cu.equals(user[counter])) { //schaut nach an welcher Stelle der Benutzer in der Liste ist
				correct_password = user[counter + 1]; //wenn gefunden geht er eine Position weiter und gibt das Passwort zur�ck
			}
			counter += 3; //0, 3, 6, 9, 12, 15...'te Position
		}
	}
	
	
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * gibt das zum Benutzernamen dazugeh�rige richtige Passwort zur�ck
	 */
	public String getUserPassword() {
		return correct_password;
	}
	
	
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * um einen Benutzer aus beliebigen Zwecken auszuw�hlen
	 */
	public void selectUser(String su) {
		selected_user = su; //wird der Variable "selected_user" zugewiesen
	}
	
	
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * Benutzer hinzuf�gen
	 */
	public void addUser(String u) {
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * die alten Arrays werden abgespeichert
		 */
		ArrayList<String> old_user_list = new ArrayList<String>();
		for (int i = 0; i < user.length; i++) {
			old_user_list.add(user[i]);
		}
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * eine neue Array wird erstellt mit einer neuen Position (drei Durchl�ufe gleich drei Positionen)
		 */
		user = new String [user.length + 1];
		
		user[user.length - 1] = u; //der neue Wert wird der neuen Array hinzugef�gt
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * die Arrayliste und der neue Array werden kombiniert so das ein neuer Wert an das Ende hinzugef�gt wird
		 */
		for (int i = 0; i < old_user_list.size(); i++) {
			user[i] = old_user_list.get(i);
		}
	}
	
	
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * erm�glicht es die Token eines Benutzers zu Bearbeiten (Geben/Nehmen)
	 */
	public void setToken(int t) {
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * dieser Teil findet den Benutzernamen in der Array "user"
		 */
		int counter = 0; //"counter" wird beim weiteren durchlauf auf Null gesetzt
		for (int i = 0; i < user.length / 3; i++) { //durch drei weil drei objekte immmer ein Benutzer sind
			if (selected_user.equals(user[counter])) {
				break; //unterbricht wenn er den Benutzernamen gefunden hat, die Position wird dann im "counter" gespeichert
			}
			counter += 3; //0, 3, 6, 9, 12, 15...'te Position
		}
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * Bearbeiten des dreitten Strings also der Anzahl der Token die ein User hat ("t" ist hierbei die Anzahl wie viele abgezogen werden)
		 */
		if (Integer.parseInt(user[counter + 2]) + t < 0) { //wenn die Eingabe in den Minus Bereich f�hren w�rde
			printer_class.errLog("Eingabe ung�ltig, w�rde zu Fehlern f�hren");
		} else {
			Integer current_token_amount = Integer.parseInt(user[counter + 2]) + t; //Token String von "user" wird zu Integer und plus die Anzahl der Token die durchgegeben wurde ("t")
			
			user[counter + 2] = current_token_amount.toString(); //Integer wird wieder zu String und in der Array "user" Bearbeitet
			
			printer_class.printLog(user[counter] + " >> " + t + " | Gesamt: " + current_token_amount.toString() + " Token");
			
		}
	}
	
	
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * zum Abfragen der Token mit dem Benutzer "current_user"
	 */
	public int getToken() {
		int counter = 0;
		for (int i = 0; i < user.length / 3; i++) {
			if (current_user.equals(user[counter])) {
				break;
			}
			counter += 3;
		}
		return Integer.parseInt(user[counter + 2]);
	}
	
	
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * Zum l�schen von Benutzern
	 */
	public void deleteUser() {
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * in diesem Schritt wird der Benutzer gel�scht sofern er nicht bereits gel�scht wurde
		 */
		int counter = 0; //"counter" wird beim weiteren durchlauf automatisch auf Null gesetzt
		for (int i = 0; i < user.length / 3; i++) { //durch drei weil drei objekte immmer ein Benutzer sind
			if (selected_user.equals(user[counter])) {
				break; //unterbricht wenn er den Benutzernamen gefunden hat, die Position wird dann im "counter" gespeichert
			}
			counter += 3; //0, 3, 6, 9, 12, 15...'te Position
		}
			
		printer_class.printLog("Benuter " + user[counter] + " wird gel�scht...");
			
		user[counter] = null; //Benutzername wird auf "null" gesetzt
		user[counter + 1] = null; //Passwort wird auf "null" gesetzt
		user[counter + 2] = null; //Token werden auf "null" gesetzt
			
		//die letzten Strings wo Informationen hinterlegt seien k�nnten wenn er sich zuvor eingeloggt hat
		correct_password = "";
		selected_user = "";
		current_user = "";
	}
	
	
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * Benutzer der gerade eingeloggt ist angeben
	 */
	public void currentUser(String u) {
		current_user = u;
	}
	
	
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * Benutzer der gerade eingeloggt ist
	 */
	public String getCurrentUser() {
		return current_user;
	}
	
	
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * Wenn man ein Benutzer hinzuf�gen will wird hier �berpr�ft ob der Benutzer bereits exisitert
	 */
	public boolean checkUser(String u) {
		userThere = false;
		int counter = 0;
		for (int i = 0; i < user.length / 3; i++) {
			if (u.equals(user[counter]) || u.isEmpty()) {
				userThere = true;
				break;
			}
			counter += 3;
		}
		return userThere;
	}
	
	public boolean getCheckUser() {
		return userThere;
	}
	
	
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * anzahl an Benutzern die das Programm benutzen
	 */
	public int totalUsers() {
		return user.length/3;
	}
}
