package com.hwrpb_system.controller;

public class Printer {
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * "Printer" Klasse
	 * Verhilft bei der Konsolenausgabe
	 */
	
	
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * Printer
	 */
	public void printLog(String p) {
		System.out.println("[ OK ] " + p);
	}
	
	public void printNoLineLog(String p) {
		System.out.print("[ OK ] " + p);
	}
	
	public void errLog(String e) {
		System.err.println("[ FEHLER ] " + e);
	}
	
	public void actionLog(String e) {
		System.out.println("[ EVENT ] " + e);
	}
}
