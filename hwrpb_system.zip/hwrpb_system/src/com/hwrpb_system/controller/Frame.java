package com.hwrpb_system.controller;

import java.awt.Point;
import java.io.IOException;

public class Frame {
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * "Frame" Klasse
	 * JFrame Verwaltung
	 */
	
	
	Printer printer_class = new Printer();
	
	public Frame() throws IOException {
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * Generelle Informationen f�r Konsolenausgabe
		 */
		printer_class.printLog(com.hwrpb_system.controller.Frame.class + " startet...");
	}
	
	
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * tempor�re Speicher
	 */
	static Point frame_location; //speichert die letzte Position eines JFrames auf dem Bildschirm ab
		
		
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * speichert die letzte Position eines JFrames auf dem Bildschirm ab
	 * andere Klassen k�nnen es �ber "setFrameLocation" abspeichern
	 */
	public void setFrameLocation(Point l) {
		frame_location = l;
	}
	
	
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * erm�glicht es die letzte Position eines JFrames abzufragen
	 */
	public Point getLastFrameLocation() {
		return frame_location;
	}
}
