package com.hwrpb_system.controller;

import java.awt.Point;

public class Frame {
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * "Frame" Klasse
	 * JFrame Verwaltung
	 */
	
	
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * tempor�re Speicher
	 */
	static Point frame_location; //speichert die letzte Position eines JFrames auf dem Bildschirm ab
		
		
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * speichert die letzte Position eines JFrames auf dem Bildschirm ab
	 * andere Klassen k�nnen es �ber "setFrameLocation" abspeichern
	 */
	public void setFrameLocation(Point l) {
		frame_location = l;
	}
	
	
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * erm�glicht es die letzte Position eines JFrames abzufragen
	 */
	public Point getLastFrameLocation() {
		return frame_location;
	}
}
