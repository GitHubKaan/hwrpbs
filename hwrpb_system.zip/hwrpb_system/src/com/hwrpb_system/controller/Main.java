package com.hwrpb_system.controller;

import java.io.IOException;
import com.hwrpb_system.extra.Debugger;
import com.hwrpb_system.ui.Login;

public class Main {
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * "Main" Klasse
	 * Main Klasse fundiert �bergeordnet
	 */
	
	
	public static void main(String[] args) throws IOException { //"throws IOException" f�ngt Fehler im gesamten code ab, somit ist try/catch nicht n�tig
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * Generelle Informationen f�r Konsolenausgabe
		 */
		System.out.println("hwrpb_system startet...");
		System.out.println("\n"
						 + "Name: HWR-Payback\n"
						 + "	|_ Main: " + com.hwrpb_system.controller.Main.class + "\n"
						 + "	|_ Version: 0.0.1" + "\n"
						 + "Entwickler: kaan, natasza, furkan, nurdan\n"
						 + "	|_ Semester: WS 2021/22\n"
						 + "	|_ Universit�t: Hochschule f�r Wirtschaft und Recht Berlin - Campus Sch�neberg\n"
						 + "	|_ Kurs: 315202 Objektorientierte Programmierung II (Gruppe 02)\n"
						 + "	|_ Dozent: Prof. Dr. Markus Schaal\n");
		
		System.out.println(com.hwrpb_system.controller.Main.class + " startet...");
		
		
		//----------<<|[ABSCHNITT]|>>----------
		/*
		 * Klassen Importieren
		 */
		new Debugger();
		new Login();
	}
}
