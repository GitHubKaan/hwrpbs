package com.hwrpb_system.controller;

import java.awt.Font;
import java.io.IOException;

public class Fonts {
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * klassen�bergreifende Schriftart Einstellung
	 * diese Schriftart wird �berall verwendet
	 */
	Printer printer_class = new Printer();
	
	public Fonts() throws IOException {
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * Generelle Informationen f�r Konsolenausgabe
		 */
		printer_class.printLog(com.hwrpb_system.controller.Fonts.class + " startet...");
	}
	
	public Font getFontTypeA() {
		return new Font("Arial", Font.PLAIN, 16);
	}
	
	public Font getFontTypeB() {
		return new Font("Calibri", Font.BOLD, 30);
	}
	
	public Font getFontTypeC() {
		return new Font("Calibri", Font.BOLD, 18);
	}
}
