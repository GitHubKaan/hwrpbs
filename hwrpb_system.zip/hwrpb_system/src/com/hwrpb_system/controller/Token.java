package com.hwrpb_system.controller;

import java.io.IOException;

public class Token {
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * "Token" Klasse
	 * verarbeitung von Token bezogenen Daten
	 */
	
	Printer printer_class = new Printer();
	
	
	public Token() throws IOException {
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * Generelle Informationen f�r Konsolenausgabe
		 */
		printer_class.printLog(com.hwrpb_system.controller.Token.class + " startet...");
	}
	
	
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * erm�glicht es die Token eines Benutzers zu Bearbeiten (Geben/Nehmen)
		 */
		public void setToken(int t) {
			//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
			/*
			 * dieser Teil findet den Benutzernamen in der Array "user"
			 */
			int counter = 0; //"counter" wird beim weiteren durchlauf auf Null gesetzt
			for (int i = 0; i < User.user.length / 3; i++) { //durch drei weil drei objekte immmer ein Benutzer sind
				if (User.selected_user.equals(User.user[counter])) {
					break; //unterbricht wenn er den Benutzernamen gefunden hat, die Position wird dann im "counter" gespeichert
				}
				counter += 3; //0, 3, 6, 9, 12, 15...'te Position
			}
			
			//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
			/*
			 * Bearbeiten des dreitten Strings also der Anzahl der Token die ein User hat ("t" ist hierbei die Anzahl wie viele abgezogen werden)
			 */
			if (Integer.parseInt(User.user[counter + 2]) + t < 0) { //wenn die Eingabe in den Minus Bereich f�hren w�rde
				printer_class.errLog("Eingabe ung�ltig, w�rde zu Fehlern f�hren");
			} else {
				Integer current_token_amount = Integer.parseInt(User.user[counter + 2]) + t; //Token String von "user" wird zu Integer und plus die Anzahl der Token die durchgegeben wurde ("t")
				
				User.user[counter + 2] = current_token_amount.toString(); //Integer wird wieder zu String und in der Array "user" Bearbeitet
				
				printer_class.printLog(User.user[counter] + " >> " + t + " | Gesamt: " + current_token_amount.toString() + " Token");
				
			}
		}
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * zum Abfragen der Token mit dem Benutzer "current_user"
		 */
		public int getToken() {
			int counter = 0;
			for (int i = 0; i < User.user.length / 3; i++) {
				if (User.current_user.equals(User.user[counter])) {
					break;
				}
				counter += 3;
			}
			return Integer.parseInt(User.user[counter + 2]);
		}
	
}
