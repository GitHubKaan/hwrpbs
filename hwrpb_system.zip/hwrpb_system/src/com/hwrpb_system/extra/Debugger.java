package com.hwrpb_system.extra;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.URL;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

import com.hwrpb_system.controller.Container;
import com.hwrpb_system.controller.Printer;

public class Debugger implements ActionListener { //implementiert den "ActionListener"
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * "Debugger" Klasse
	 * dient zur Verwaltung von Benutzer Eigenschaften
	 * Token k�nnen hinzugef�gt oder gel�scht werden
	 * Benutzer k�nnen gel�scht oder hinzugef�gt werden
	 */
	
	
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * generelle Einstellungen
	 */
	static int debugger = 0; //0 = inaktiv, 1 = aktiv
	
	
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * Objekt Arraylisten und Positionierung
	 * 
	 * Positionsierung:
	 * 		panel 0 - Dropdown Men� (Accountname)
	 * 		panel 1 - +1 Token
	 * 		panel 2 - +5 Token
	 * 		panel 3 - +10 Token
	 * 		panel 4 - -1 Token
	 * 		panel 5 - -5 Token
	 * 		panel 6 - -10 Token
	 * 		panel 7 - Benutzer l�schen
	 * 		panel 8 - Benutzer hinzuf�gen
	 * 		panel 9 - Benutzername hinzuf�gen
	 * 		panel 10 - Passwort hinzuf�gen
	 * 		panel 11 - Token hinzuf�gen
	 */
	JPanel[] panels = new JPanel[100]; //Panels und Buttons werden erstellt in einer Arrayliste
	JButton[] buttons = new JButton[100];
	JTextField[] textfields = new JTextField[100];

	
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * Imports von Klassen Methoden etc. zum abrufen
	 */
	Container container_class = new Container();
	Printer printer_class = new Printer();
	
	
	public Debugger() throws IOException  {
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * Generelle Informationen f�r Konsolenausgabe
		 */
		printer_class.printLog(com.hwrpb_system.controller.Main.class + " startet...");
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * Initialisierung der Arraylisten
		 */
		for (int i = 0; i < 100; i++) {
		    panels[i] = new JPanel();
			buttons[i] = new JButton();
			textfields[i] = new JTextField();
		}
	
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * JFrame "frame" Einstellungen/Eigenschaften
		 */
		JFrame frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(225, 230);
		frame.setLocation(0, 0); //fenster �ffnet sich in der Mitte des Bildschirmes
		frame.setTitle("debugger");
		frame.setLayout(null); //kein Layoutmanager also muss man die Koordinaten manuell eingeben f�r Objekte auf dem "frame"
		frame.setResizable(false);
		frame.getContentPane().setBackground(Color.DARK_GRAY);
		
		URL icon_image_url = getClass().getResource("/textures/extra/icon2.png");
		ImageIcon icon = new ImageIcon(icon_image_url);
		frame.setIconImage(icon.getImage());
	
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * Panels Einstellungen ("panels" haben eine organisatorische Funktion)
		 */
		for (int i = 0; i < panels.length; i++) { //Panels unsichtbar machen
		    panels[i].setOpaque(false);
		    panels[i].setLayout(new BorderLayout(0, 0)); //Funktioniert wie ".pack" damit die Objekte sich an die Gr��e des "panels" anpassen 
		}
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		* Benutzer w�hlen Textfeld
		*/
		textfields[3].setFont(container_class.getFontTypeA()); //"Container" Klasse wird abgerufen um die Font zu bekommen
		
		panels[0].setBounds(0, 0, 210, 20);
		panels[0].add(textfields[3]);
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		* JButton Verwaltung
		*/
		buttons[0].setText("+1");
		panels[1].setBounds(0, 20, 70, 30);
		buttons[1].setText("+5");
		panels[2].setBounds(70, 20, 70, 30);
		buttons[2].setText("+10");
		panels[3].setBounds(140, 20, 70, 30);
		buttons[3].setText("-1");
		panels[4].setBounds(0, 50, 70, 30);
		buttons[4].setText("-5");
		panels[5].setBounds(70, 50, 70, 30);
		buttons[5].setText("-10");
		panels[6].setBounds(140, 50, 70, 30);
		buttons[6].setText("Konto l�schen");
		panels[7].setBounds(0, 80, 210, 30);
		buttons[7].setText("Konto hinzuf�gen (B, P, T)");
		panels[8].setBounds(0, 160, 210, 30);
		
		for (int i = 0; i < 8; i++) {
			panels[i + 1].add(buttons[i]);
		}
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * Benutzer hinzuf�gen JTextField
		 */
		panels[9].setBounds(0, 130, 70, 30);
		panels[10].setBounds(70, 130, 70, 30);
		panels[11].setBounds(140, 130, 70, 30);
		
		for (int i = 0; i < 3; i++) {
			panels[i + 9].add(textfields[i]);
		}
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * Actionevents implementieren
		 * diese lassich sich weiter unten im Code auffinden
		 */
	    for (int i = 0; i < buttons.length; i++) {
	    	buttons[i].addActionListener(this);
	    
	    
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * JPanels den JFrame hinzuf�gen
		 */
			frame.add(panels[i]);
		}
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * rendert JFrame "frame" neu und macht es visible
		 * Code-Zeile sollte am besten immer ganz unten stehen so das alle Objekte gerendert werden
		 */
		if (debugger == 1) { //muss manuell angemacht werden
			frame.setVisible(true);
		}
	}
	
	
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * Actionevents
	 */
	public void actionPerformed(ActionEvent e) {
		printer_class.actionLog("JButton Action > Debugger");
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * Konto hinzuf�gen
		 * es ist wichtig das bei dem Token-Wert kein Buchstabe eingegeben wird
		 * zudem sollte man kein Feld frei lassen da das System sonst durcheinander kommt
		 */
		if (e.getSource() == buttons[7]) { //"Benutzer hinzuf�gen" JButton
			if (textfields[0].getText().isEmpty() || textfields[1].getText().isEmpty() || textfields[2].getText().isEmpty()) { //Wenn einer der Felder leer ist (Fehler tritt auf wenn das letzte Feld keine Zahl ist, m�sste man noch beheben, w�re aber komplex)
				printer_class.errLog("bitte f�lle alle Felder aus bevor du einen Benutzer hinzuf�gst");
			} else {
				container_class.checkUser(textfields[0].getText()); //hier wird �berpr�ft ob der Benutzer bereits exisitert
				
				if (container_class.getCheckUser() == false) {
					for (int i2 = 0; i2 < 3; i2++) { //weil genau drei Werte eingetragen werden m�ssen
						container_class.addUser(textfields[i2].getText());
					}
					
					printer_class.printLog("Benutzer " + textfields[0].getText() + " wurde erfolgreich hinzugef�gt");
					
					for (int i = 0; i < 3; i++) {
						textfields[i].setText("");
					}
				} else {
					printer_class.errLog("Benutzer kann nicht hinzugef�gt werden, bitte �berpr�fe deine Eingabe");
				}
			}
		} else { //wenn Benutzer nicht hinzugef�gt werden soll, geht er in die Operation Benuzer finden f�r -> Konto l�schen etc.
			
			
			//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
			/*
			 * gibt den ausgew�hlten Benutzernamen zun�chst an die "Container" Klasse durch
			 */
			int user_found = 0; //um zu schauen ob der Benutzer existiert
			for (int i = 0; i < container_class.getUsers().size(); i++) {
				if (textfields[3].getText().equals(container_class.getUsers().get(i))) {
					printer_class.printLog("Benutzer gefunden...");
					
					container_class.selectUser(textfields[3].getText()); //wandelt das Objekt (Benutzernamen) in der JCombobox in ein String um
					
					//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
					/*
					 * f�gt Token hinzu oder entnimmt sie dem ausgew�hlten Benutzer
					 * 
					 * Vorgehensweise:
					 * 		1. die Schleife geht sechs mal durch weil es auch nur sechs JButtons gibt die mit der Vergabe oder Annahme von Tokens besch�ftigen
					 * 		2. es wird geschaut welcher JButton bet�tigt wurde
					 * 		3. die Methode "editUserToken" wird in der "Container" Klasse abgerufen um die Token zu bearbeiten
					 * 		4. es wird der JButton Text (bsp. "-10") zu einem Integer umgewandelt und dann zur Methode geschickt
					 */
			    	for (int i2 = 0; i2 < 6; i2++) { //weil es genau sechs JButtons gibt die f�r die Vergabe oder Abnahme von Token gibt
			    		if (e.getSource() == buttons[i2]) {
			    			container_class.setToken(Integer.parseInt(buttons[i2].getText()));
			    		}
			    	}
			    	
			    	
			    	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
					/*
					 * Konto l�schen
					 */
					if (e.getSource() == buttons[6]) {
						if (container_class.getCurrentUser().equals(textfields[3].getText())) { //wenn Benutzer gerade angemeldet
							printer_class.errLog("Benutzer der gel�scht wird ist derzeit angemeldet, eine L�schung kann daher nicht erfolgen");
						} else {
							container_class.deleteUser(); //Benutzer wurde bereits in der "Container" Klasse gel�scht
							
							textfields[3].setText("");
							
							printer_class.printNoLineLog("Alle verbleibenden Benutzer: ");
							for (int i3 = 0; i3 < container_class.getUsers().size(); i3++) { //Auflistung der exestierenden Benutzer
								if (container_class.getUsers().get(i3) != null) {
									System.out.print(container_class.getUsers().get(i3));
									
									if (i3 != container_class.getUsers().size() - 1) { //damit hinter dem letzten Benutzernamen kein Komma steht und hinter allen anderen schon
										System.out.print(", ");
									}
								}
							}
							System.out.println();
						}
					}
				} else {
					user_found++; //jedesmal wenn Benutzer nicht gefunden steigt der Counter um eins
				}
			}
			if (user_found == container_class.getUsers().size()) { //wenn Benutzer nicht gefunden weden konnte
				if (textfields[3].getText().isEmpty()) { //wenn "textfields[3] leer ist
					printer_class.errLog("Angegebener Benutzer konnte nicht gefunden werden da Textfeld leer ist");
				} else {
					printer_class.errLog("Angegebener Benutzer konnte nicht gefunden werden, �berpr�fe den Benutzernamen");
				}
			}
			user_found = 0;
		}
    }
}
