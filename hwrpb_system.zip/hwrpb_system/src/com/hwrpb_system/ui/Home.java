package com.hwrpb_system.ui;

import java.awt.BorderLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import com.hwrpb_system.controller.User;
import com.hwrpb_system.controller.Fonts;
import com.hwrpb_system.controller.Frame;
import com.hwrpb_system.controller.Main;
import com.hwrpb_system.controller.Printer;
import com.hwrpb_system.controller.Token;

public class Home implements ActionListener {
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * "Home" Klasse
	 * diese Klasse dient zur Navigierung des Benutzers
	 * Informationen werden von "Container" Klasse abgefragt
	 */
	
	
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * Objekt Arraylisten und Positionierung
	 * 
	 * Positionsierung:
	 * 		panel 0 - Hintergrundsebene
	 * 		panel 1 - Einstellungen
	 * 		panel 2 - Nachricht
	 * 		panel 3 - Shop
	 * 		panel 4 - Anleitung
	 *		panel 5 - Zur�ck
	 *		panel 6 - Token Anzeige
	 */
	static JPanel[] panels = new JPanel[100];
	static JLabel[] labels = new JLabel[100]; 
	static JButton[] buttons = new JButton[100];
	
	
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * Imports von Klassen Methoden etc. zum abrufen
	 */
	User user_class = new User();
	Settings settings_class = new Settings();
	Help help_class = new Help();
	Shop shop_class = new Shop();
	Printer printer_class = new Printer();
	Frame frame_class = new Frame();
	Fonts fonts_class = new Fonts();
	Token token_class = new Token();
	
	
	public Home() throws IOException { //"throws IOException" f�ngt Fehler im gesamten Code ab, somit ist try/catch nicht erforderlich
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * Generelle Informationen f�r Konsolenausgabe
		 */
		printer_class.printLog(com.hwrpb_system.ui.Home.class + " startet...");
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * Initialisierung der Arraylisten
		 */
		for (int i = 0; i < 100; i++) {
		    panels[i] = new JPanel();
			labels[i] = new JLabel();
			buttons[i] = new JButton();
		}
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * JFrame "frame" Einstellungen/Eigenschaften
		 */
		JFrame frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(400, 800);
		frame.setTitle("hwrpb_system - home ui");
		frame.setResizable(false);
		frame.setLocation(frame_class.getLastFrameLocation()); //Platziert den Home-JFrame dort hin wo der Login-JFrame zuletzt war
		
		URL icon_image_url = getClass().getResource("/textures/extra/icon.png");
		ImageIcon icon = new ImageIcon(icon_image_url);
		frame.setIconImage(icon.getImage());
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * JPanels aus anderen Klassen hinzuf�gen
		 */
		frame.add(settings_class);
		frame.add(help_class);
		frame.add(shop_class);
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * Panels Einstellungen ("panels" haben eine organisatorische Funktion)
		 */
		for (int i = 0; i < panels.length; i++) { //JPanels unsichtbar machen
		    panels[i].setOpaque(false);
		    panels[i].setLayout(new BorderLayout(0, 0)); //Funktioniert wie ".pack" damit die Objekte sich an die Gr��e des "panels" anpassen
		}
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * Positionierung und Einstellungen f�r die JButtons
		 */
		panels[1].setBounds(350, 5, 30, 30);
		panels[2].setBounds(30, 134, 385, 79);
		panels[3].setBounds(0, 227, 385, 168);
		panels[4].setBounds(0, 407, 385, 168);
		panels[5].setBounds(10, 10, 35, 35);
		
		for (int i = 1; i < 6; i++) { //nur die oben angegebenen JPanel werden hier f�r die JButtons ber�cksichtigt
			if (i != 2) { //Transaktions-JPanel
				panels[i].add(buttons[i - 1]); //-1 weil die Schleife bei eins startet
			}
		}
		
		for (int i = 0; i < buttons.length; i++) {
			buttons[i].setOpaque(false);
			buttons[i].setContentAreaFilled(false);
			buttons[i].setBorderPainted(false);
			
			buttons[i].addActionListener(this);
		}
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * Token Anzeige
		 */
		labels[1].setFont(fonts_class.getFontTypeB());
		
		validateToken(); //Kontostand Abfragen/erneuern
		
		panels[6].setBounds(87, 62, 288, 30);
		panels[6].add(labels[1]);
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * Nachricht
		 */
		labels[2].setFont(fonts_class.getFontTypeC());
		
		labels[2].setText("<html>Willkommen zur�ck " + user_class.getCurrentUser().substring(0, 1).toUpperCase() + user_class.getCurrentUser().substring(1) + "!<br/>Anzahl der gesamten Benutzer: " + user_class.totalUsers() + ".</html>"); //das mit substring ist damit der Name gro� geschrieben wird
		
		panels[2].add(labels[2]);
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * JPanels den JFrame hinzuf�gen
		 */
		for (int i = 0; i < panels.length; i++) {
			frame.add(panels[i]);
		}
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * Hintergrundsebene
		 */
		labels[0].setBounds(0, 0, 385, 761); //label Gr��e bestimmen
		
		URL image_url = Main.class.getResource("/textures/background/homebg.png");
		
		BufferedImage image = null;
		try { //Bild Import
			image = ImageIO.read(image_url);
		} catch (IOException e) {
			e.printStackTrace();
		}
				
		Image scaled_image = image.getScaledInstance(labels[0].getWidth(), labels[0].getHeight(), Image.SCALE_REPLICATE); //passt das Bild der Gr��e des JLabels an, "SCALE_REPLICATE" ist die Art wir die Pixel gescaled und verarbeitet werden
				
		ImageIcon bgimage = new ImageIcon(scaled_image);
				
		labels[0].setIcon(bgimage);
		labels[0].setBounds(0, 0, 385, 761); //label Gr��e bestimmen
				
		frame.add(labels[0]); //"label 0" wird dem "frame" zugewiesen
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * rendert JFrame "frame" neu und macht es visible
		 * Code-Zeile sollte am besten immer ganz unten stehen so das alle Objekte gerendert werden
		 */
		frame.setVisible(true);
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * Actionevents von Objekten anderer Klassen
		 */
		settings_class.buttons[1].addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				user_class.currentUser(""); //damit falls das Konto gel�scht werden soll es freigegeben wird in der "Debugger" Klasse
				
				frame.setVisible(false); //macht diesen JFrame unsichtbar
				
				frame_class.setFrameLocation(frame.getLocation());
				
				try { //versucht Login-Klasse erneut zu �ffnen
					new Login();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				
				printer_class.actionLog("JButton Event > Settings");
				
				printer_class.printLog("Benutzer wird abgemeldet...");
			}
		});
	}
	
	
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * Actionevents von Objekten dieser Klasse
	 */
	public void actionPerformed(ActionEvent e) {
		printer_class.actionLog("JButton Event > Home");
		
		if (e.getSource() == buttons[0]) { //Einstellungen
			settings_class.setVisible(true);
			homeClose();
		}
		
		if (e.getSource() == buttons[2]) { //Shop
			shop_class.setVisible(true);
			homeClose();
		}
		
		if (e.getSource() == buttons[3]) { //Hilfe
			help_class.setVisible(true);;
			homeClose();
		}
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * Actionevents die von anderen Klassen ausgef�hrt werden k�nnen
		 */
		if (e.getSource() == buttons[4]) { //Zur�ck JButton schaltet wieder auf die Home-Klasse zur�ck
			settings_class.setVisible(false);
			help_class.setVisible(false);
			shop_class.setVisible(false);
			
			validateToken(); //den Token Kontostand aktuallisieren
			
			homeOpen();
		}
	}
	
	
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * Aktivierungs und Deaktivierungs Optionen bei Verlassen der Home-Klasse
	 */
	private void homeOpen() {
		for (int i = 0; i < buttons.length; i++) {
			buttons[i].setVisible(true);
		}
	}
	
	private void homeClose() {
		for (int i = 0; i < buttons.length; i++) {
			if (i != 4) { //weil der vierte Button zum Zur�ckgehen gedacht ist
				buttons[i].setVisible(false);
			}
		}
	}
	
	
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * Ausgabeeinstellungen der Token Anzeige
	 */
	private void validateToken() {
		if (token_class.getToken() == 0) { //Ausgabeeinstellungen der Token-Anzeige
			labels[1].setText("Du hast keine Token");
		} else if (token_class.getToken() > 0) {
			labels[1].setText(Integer.toString(token_class.getToken()) + " Token");
		} else {
			labels[1].setText("FEHLER");
		}
	}
}
