package com.hwrpb_system.ui;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import com.hwrpb_system.controller.User;
import com.hwrpb_system.controller.Main;
import com.hwrpb_system.controller.Printer;

public class Help extends JPanel {
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * "Help" Klasse
	 */
	
	
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * Objekt Arraylisten und Positionierung
	 * 
	 * Positionsierung:
	 * 		panel 0 - Hintergrundsebene
	 */
	JPanel[] panels = new JPanel[100];
	JLabel[] labels = new JLabel[100];
	
	
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * Imports von Klassen Methoden etc. zum abrufen
	 */
	Printer printer_class = new Printer();
	
	
	public Help() throws IOException {
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * Generelle Informationen f�r Konsolenausgabe
		 */
		printer_class.printLog(com.hwrpb_system.ui.Help.class + " startet...");
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * Initialisierung der Arraylisten
		 */
		for (int i = 0; i < 100; i++) {
		    panels[i] = new JPanel();
			labels[i] = new JLabel();
		}
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * Settings-JPanel Einstellungen/Eigenschaften
		 */
		setBounds(0, 0, 400, 800); //-4 kommt zustande weil sich das Bild auf dem JPanel verschiebt
		setVisible(false);
		setLayout(null); //erm�glicht es Objekte frei zu platzieren
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * JPanels Einstellungen ("panels" haben eine organisatorische Funktion)
		 */
		for (int i = 0; i < panels.length; i++) { //JPanels unsichtbar machen
		    panels[i].setOpaque(false);
		}
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * Hintergrundsebene
		 */
		panels[0].setBounds(0, 0, 385, 761); //enspricht 400 und 800 JFrame Pixeln warum auch immer
		panels[0].setLayout(null); //freies Platzieren
				
		labels[0].setBounds(0, 0, 385, 761); //label Gr��e bestimmen
				
		URL image_url = Main.class.getResource("/textures/background/helpbg.png");
				
		BufferedImage image = null;
		try { //Bild Import
			image = ImageIO.read(image_url);
		} catch (IOException e) {
			e.printStackTrace();
		}
				
		Image scaled_image = image.getScaledInstance(labels[0].getWidth(), labels[0].getHeight(), Image.SCALE_REPLICATE); //passt das Bild der Gr��e des JLabels an, "SCALE_REPLICATE" ist die Art wir die Pixel gescaled und Verarbeitet werden
				
		ImageIcon bgimage = new ImageIcon(scaled_image);
				
		labels[0].setIcon(bgimage);
				
		panels[0].add(labels[0]);
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * JPanels werden in diesem Teil mit dem Haupt-JPanel verbunden
		 */
		for (int i = 0; i < panels.length; i++) {
			add(panels[i]);
		}
	}
}
