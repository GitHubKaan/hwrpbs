package com.hwrpb_system.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import com.hwrpb_system.controller.Container;
import com.hwrpb_system.controller.Frame;
import com.hwrpb_system.controller.Main;
import com.hwrpb_system.controller.Printer;

public class Login {
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * "Login" Klasse
	 * Login-Informationen werden von "Container" Klasse kontrolliert
	 * der Login l�sst sich mit "no_passoword" auf 1 umgehen
	 */
	
	
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * Objekt Arraylisten und Positionierung
	 * 
	 * Positionsierung:
	 * 		panel 0 - Hintergrundsebene
	 * 		panel 1 - Dropdown Men� (Accountname)
	 * 		panel 2 - Passwort-Textfeld
	 * 		panel 3 - Anmelde-Button
	 */
	static JPanel[] panels = new JPanel[100];
	static JLabel[] labels = new JLabel[100]; 
	static JButton[] buttons = new JButton[100];
	static JTextField[] textfields = new JTextField[100];
	
	
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * tempor�re Speicher
	 */
	static int wrong_password_counter = 0; //bei falscher Passworteingabe steigt der Counter um eins
	
	
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * Imports von Klassen Methoden etc. zum abrufen
	 */
	Container container_class = new Container(); //"Container" Klasse zum abrufen der Login-Informationen
	Printer printer_class = new Printer();
	Frame frame_class = new Frame();
	
	
	public Login() throws IOException { //"throws IOException" f�ngt Fehler im gesamten Code ab, somit ist try/catch nicht erforderlich
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * Generelle Informationen f�r Konsolenausgabe
		 */
		printer_class.printLog(com.hwrpb_system.ui.Login.class + " startet...");
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * Initialisierung der Arraylisten
		 */
		for (int i = 0; i < 100; i++) {
		    panels[i] = new JPanel();
			labels[i] = new JLabel();
			buttons[i] = new JButton();
			textfields[i] = new JTextField();
		}
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * JFrame "frame" Einstellungen/Eigenschaften
		 */
		JFrame frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(400, 800);
		
		if (frame_class.getLastFrameLocation() == null) { //wenn man sich beispielsweise Abmelden will dann speichert die Home-Klasse die letzt Position
			frame.setLocationRelativeTo(null); //fenster �ffnet sich in der Mitte des Bildschirmes
		} else {
			frame.setLocation(frame_class.getLastFrameLocation());
		}
		
		frame.setTitle("hwrpb_system - login ui");
		frame.setLayout(null); //kein Layoutmanager also muss man die Koordinaten manuell eingeben f�r Objekte auf dem "frame"
		frame.setResizable(false);
		
		URL icon_image_url = getClass().getResource("/textures/extra/icon.png");
		ImageIcon icon = new ImageIcon(icon_image_url);
		frame.setIconImage(icon.getImage());
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * JPanels Einstellungen ("panels" haben eine organisatorische Funktion)
		 */
		for (int i = 0; i < panels.length; i++) { //JPanels unsichtbar machen
		    panels[i].setOpaque(false);
		    panels[i].setLayout(new BorderLayout(0, 0)); //Funktioniert wie ".pack" damit die Objekte sich an die Gr��e des "panels" anpassen
		}
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		* JTextField f�r Accountname
		*/
		textfields[0].setFont(container_class.getFontTypeA()); //"Container" Klasse wird abgerufen um die Font zu bekommen
		
		panels[1].setBounds(52, 331, 281, 43);
		panels[1].add(textfields[0]);
		
		frame.add(panels[1]);
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		* Passwort-Textfeld
		*/
		textfields[1].setFont(container_class.getFontTypeA());
		
		panels[2].setBounds(52, 387, 281, 43);
		panels[2].add(textfields[1]);
		
		frame.add(panels[2]);
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		* Anmelde-Button
		*/
		buttons[0].setOpaque(false); //button Schatten, Texture etc. unsichtbar machen
		buttons[0].setContentAreaFilled(false);
		buttons[0].setBorderPainted(false);
		
		panels[3].setBounds(135, 440, 115, 30);
		panels[3].add(buttons[0]);
		
		frame.add(panels[3]);
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * Hintergrundsebene
		 */
		labels[0].setBounds(0, 0, 385, 761); //label Gr��e bestimmen
		
		URL image_url = Main.class.getResource("/textures/background/loginbg.png");
		
		BufferedImage image = null;
		try { //Bild Import
			image = ImageIO.read(image_url);
		} catch (IOException e) {
		    e.printStackTrace();
		}
		
		Image scaled_image = image.getScaledInstance(labels[0].getWidth(), labels[0].getHeight(), Image.SCALE_REPLICATE); //passt das Bild der Gr��e des JLabels an, "SCALE_REPLICATE" ist die Art wir die Pixel gescaled und verarbeitet werden
		
		ImageIcon bgimage = new ImageIcon(scaled_image);
		
		labels[0].setIcon(bgimage);
		
		frame.add(labels[0]); //"label 0" wird dem "frame" zugewiesen
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * rendert JFrame "frame" neu und macht es visible
		 * Code-Zeile sollte am besten immer ganz unten stehen so das alle Objekte gerendert werden
		 */
		frame.setVisible(true);
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * Actionevents
		 */
		textfields[0].addActionListener(new ActionListener() { //damit man wenn man auf Enter dr�ckt bei dem Benutzernamen zum Passwort JTextField kommt
			@Override
			public void actionPerformed(ActionEvent e) {
				textfields[1].requestFocus(); //setzt den Fokus auf das zweite Textfeld
			}
		});
		
		textfields[1].addActionListener(new ActionListener() { //wenn man im "password_field" auf die Entertaste dr�ckt soll man den JButton ausl�sen
			@Override
			public void actionPerformed(ActionEvent e) {
				buttons[0].doClick(); //l�st einen Klick aus
			}
		});
		
		buttons[0].addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) { //Actionevent
				printer_class.actionLog("JButton Action > Login");
				
				container_class.setUser(textfields[0].getText()); //"schickt" der "Container" Klasse das eingegene Passwort zu
				
				printer_class.printLog("Anmeldeversuch mit " + textfields[0].getText() + "...");
				printer_class.printLog("Eingegebenes Passwort: " + textfields[1].getText());
				
				//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
				/*
				 * Kontrolle des Passwortes oder alternativ "no_password" auf 1
				 * der Benutzer hat maximal drei versuche um sich Anzumelden
				 */
				if ((textfields[1].getText().equals(container_class.getUserPassword()) && !container_class.getUserPassword().equals(""))) { //wenn das Passwortfeld dem entsprechenden Benutzernamen entspricht und nicht leer ist oder falsch
					//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
					/*
					 * richtiges Passwort wurde eingegeben
					 */
					printer_class.printLog("Passwort korrekt, Login erfolgt...");
					
					frame_class.setFrameLocation(frame.getLocation()); //speichert die Position des Login-JFrames ab
					container_class.currentUser(textfields[0].getText());
					
					frame.setVisible(false); //schaltet den Frame aus
					
					wrong_password_counter = 0; //falsche Passwort Eingaben werden wiederhergestellt f�r den n�chsten Login Versuch
					
					try {
						new Home(); //home klasse wird importiert
					} catch (IOException e2) {
						printer_class.errLog("\"Home\" Klasse konnte nicht gestartet werden");
					}
				} else {
					//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
					/*
					 * falsches Passwort wurde eingegeben
					 */
					printer_class.errLog("Passwort inkorrekt");
					
					Color loginWrong = new Color(255, 177, 177);
					textfields[0].setBackground(loginWrong); //Textfeld rot anmalen
					textfields[1].setBackground(loginWrong);
					
					wrong_password_counter++; //Bei falscher Eingabe steigt der Counter bis maximal drei
					
					textfields[0].requestFocus(); //setzt den Fokus wieder auf das Feld des Benutzernamens
					
					printer_class.printLog("falsches Passwort (Versuch): " + wrong_password_counter + "/3");
				}
				//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
				/*
				 * was in beiden F�llen passiert
				 */
				textfields[1].setText(""); //Passwort-Textfeld l�schen
				textfields[0].setText(""); //Benutzername-Textfeld l�schen
				
				if (wrong_password_counter == 3) { //Beendet das Programm wenn das Passwort drei mal falsch eingegeben wurde
					printer_class.errLog("Benutzername oder Passwort wurde zu oft falsch eingegeben, Programm wird beendet...");
							
					System.exit(0); //software wird gestoppt
				}
			}
		});
	}
}
