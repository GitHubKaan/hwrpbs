package com.hwrpb_system.ui;

import java.awt.BorderLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import com.hwrpb_system.controller.Container;
import com.hwrpb_system.controller.Main;
import com.hwrpb_system.controller.Printer;

public class Settings extends JPanel implements ActionListener {
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * "Settings" Klasse
	 * diese Klasse ist f�r die Benutzer Einstellungen gedacht
	 * diese Klasse ist eine JPanel Klasse und Teil der "Home" Klasse
	 */
	
	
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * Objekt Arraylisten und Positionierung
	 * 
	 * Positionsierung:
	 * 		panel 0 - Pers�hnliche Daten
	 * 		panel 1 - Abmelden
	 * 		panel 2 - Pers�hnliche Daten zur�ck JButton
	 * 		panel 3 - Infotext
	 * 		panel 4 - Hintergrundsebene
	 * 		panel 5 - Pers�hnliche Daten Hintergrundsebene
	 */
	JButton[] buttons = new JButton[100];
	JPanel[] panels = new JPanel[100];
	JLabel[] labels = new JLabel[100];
	
	
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * Imports von Klassen Methoden etc. zum abrufen
	 */
	Container container_class = new Container();
	Printer printer_class = new Printer();
	
	
	public Settings() throws IOException {
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * Generelle Informationen f�r Konsolenausgabe
		 */
		printer_class.printLog(com.hwrpb_system.ui.Settings.class + " startet...");
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * Initialisierung der Arraylisten
		 */
		for (int i = 0; i < 100; i++) {
		    panels[i] = new JPanel();
			buttons[i] = new JButton();
			labels[i] = new JLabel();
		}
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * Settings-JPanel Einstellungen/Eigenschaften
		 */
		setBounds(0, 0, 400, 800); //-4 kommt zustande weil sich das Bild auf dem JPanel verschiebt
		setVisible(false);
		setLayout(null); //erm�glicht es Objekte frei zu platzieren
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * JPanels Einstellungen ("panels" haben eine organisatorische Funktion)
		 */
		for (int i = 0; i < panels.length; i++) { //JPanels unsichtbar machen
		    panels[i].setOpaque(false);
		}
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * JButton und JPanel bez�glich der M�glichkeiten Verwaltung
		 */
		buttons[2].setVisible(false); //weil dieser erst wenn die zweite Settings Seite aufgeht aktiviert wird
		panels[5].setVisible(false); //gleiche gilt f�r die zweite Hintergrundsebene
				
		panels[0].setBounds(15, 68, 355, 47);
		panels[1].setBounds(15, 123, 355, 47);
		panels[2].setBounds(52, 10, 35, 35);
		
		for (int i = 0; i < 3; i++) {
			buttons[i].setOpaque(false);
			buttons[i].setContentAreaFilled(false);
			buttons[i].setBorderPainted(false);
			
			buttons[i].addActionListener(this);
			
			panels[i].setLayout(new BorderLayout(0, 0));
			panels[i].add(buttons[i]);
		}
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * Hintergrundsebene
		 */
		panels[4].setBounds(0, 0, 385, 761); //enspricht 400 und 800 JFrame Pixeln warum auch immer
		panels[4].setLayout(null); //freies Platzieren
		
		labels[1].setBounds(0, 0, 385, 761); //label Gr��e bestimmen
		
		URL image_url = Main.class.getResource("/textures/background/settingsbg.png");
		
		BufferedImage image = null;
		try { //Bild Import
			image = ImageIO.read(image_url);
		} catch (IOException e) {
		    e.printStackTrace();
		}
		
		Image scaled_image = image.getScaledInstance(labels[1].getWidth(), labels[1].getHeight(), Image.SCALE_REPLICATE); //passt das Bild der Gr��e des JLabels an, "SCALE_REPLICATE" ist die Art wir die Pixel gescaled und Verarbeitet werden
		
		ImageIcon bgimage = new ImageIcon(scaled_image);
		
		labels[1].setIcon(bgimage);
		
		panels[4].add(labels[1]);
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * JPanels werden in diesem Teil mit dem Haupt-JPanel verbunden
		 */
		for (int i = 0; i < panels.length; i++) {
			add(panels[i]);
		}
	}


	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * Actionevents
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		printer_class.actionLog("JButton Event > Settings");
		
		if (e.getSource() == buttons[0]) { //Pers�hnliche Daten (Abmelde JButton ist in der Home-Klasse)
			printer_class.printLog("�ffne Pers�hnliche Daten...");
			
			//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
			/*
			 * Umschalter
			 */
			nextPage(); //macht die normale Hintergrundsebene der Settings-Klasse unsichtbar
			
			//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
			/*
			 * Infotext
			 */
			labels[0].setText("<html><b>Benutzername:</b> " + container_class.getCurrentUser() + "<br/>" + //JLabel k�nnen im HTML-Format formatiert werden
							  "<b>Passwort:</b> " + container_class.getUserPassword() + "<br/>" +
							  "<b>Token:</b> " + container_class.getToken() + "<br/><br/>" +
							  "Falls du Hilfe ben�tigst, wende dich an<br/>unseren Support. Du kannst uns unter<br/>folgender E-Mail-Adresse kontaktieren:<br/><u>kontakt@hwr-berlin-payback.com</u>.<br/>Wir werden dir versuchen so schnell wie<br/>m�glich zu antworten." + "<br/><br/>" +
							  "Zudem lassen sich viele weitere<br/>Informationen sich auf unserer Webseite<br/>auffinden. Gehe dazu auf:<br/> <u>hwr-berlin-payback.com</u>." + "<br/><br/>" +
							  "Mit freundlichen Gr��en<br/>Dein HWRPB-Team!" + "</html>");
			labels[0].setBounds(40, 70, 300, 350);
			labels[0].setFont(container_class.getFontTypeA());
			
			panels[3].setBounds(0, 0, 385, 761);
			panels[3].setLayout(null);
			
			panels[3].add(labels[0]);
			
			//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
			/*
			 * Hintergrundsebene f�r Pers�hnliche Daten
			 */
			panels[5].setBounds(0, 0, 385, 761); //enspricht 400 und 800 JFrame Pixeln warum auch immer
			panels[5].setLayout(null); //freies Platzieren
			
			labels[2].setBounds(0, 0, 385, 761); //label Gr��e bestimmen
			
			URL image_url = Main.class.getResource("/textures/background/settingsbg2.png");
			
			BufferedImage image = null;
			try { //Bild Import
				image = ImageIO.read(image_url);
			} catch (IOException e1) {
			    e1.printStackTrace();
			}
			
			Image scaled_image = image.getScaledInstance(labels[2].getWidth(), labels[2].getHeight(), Image.SCALE_REPLICATE); //passt das Bild der Gr��e des JLabels an, "SCALE_REPLICATE" ist die Art wir die Pixel gescaled und Verarbeitet werden
			
			ImageIcon bgimage = new ImageIcon(scaled_image);
			
			labels[2].setIcon(bgimage);
			
			panels[5].add(labels[2]);
		}
		
		if (e.getSource() == buttons[2]) { //um Zur�ck auf die erste Settings Seite zu kommen
			previousPage();
		}
	}
	
	
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * Aktivierungs und Deaktivierungs Optionen bei Verlassen der Hautpseite
	 */
	private void nextPage() {
		panels[4].setVisible(false);
		panels[5].setVisible(true);
		
		buttons[0].setVisible(false);
		buttons[1].setVisible(false);
		
		buttons[2].setVisible(true);
		
		panels[3].setVisible(true);
		
		repaint();
	}
	
	private void previousPage() {
		panels[4].setVisible(true);
		panels[5].setVisible(false);
		
		buttons[0].setVisible(true);
		buttons[1].setVisible(true);
		
		buttons[2].setVisible(false);
		
		panels[3].setVisible(false);
		
		repaint();
	}
}
