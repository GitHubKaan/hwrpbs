package com.hwrpb_system.ui;

import java.awt.BorderLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import com.hwrpb_system.controller.Container;
import com.hwrpb_system.controller.Main;
import com.hwrpb_system.controller.Printer;

public class Shop extends JPanel implements ActionListener {
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * "Shop" Klasse
	 */
	
	
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * Objekt Arraylisten und Positionierung
	 */
	JPanel[] panels = new JPanel[100];
	JButton[] buttons = new JButton[100];
	JLabel[] labels = new JLabel[100];
	
	
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * Imports von Klassen Methoden etc. zum abrufen
	 */
	Container container_class = new Container();
	Printer printer_class = new Printer();
	
	
	public Shop() throws IOException {
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * Generelle Informationen f�r Konsolenausgabe
		 */
		printer_class.printLog(com.hwrpb_system.ui.Shop.class + " startet...");
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * Initialisierung der Arraylisten
		 */
		for (int i = 0; i < 100; i++) {
		    panels[i] = new JPanel();
		    buttons[i] = new JButton();
			labels[i] = new JLabel();
		}
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * Settings-JPanel Einstellungen/Eigenschaften
		 */
		setBounds(0, 0, 400, 800); //-4 kommt zustande weil sich das Bild auf dem JPanel verschiebt
		setVisible(false);
		setLayout(null); //erm�glicht es Objekte frei zu platzieren
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * JButtons zum kaufen eines Produktes
		 */
		//aktuelle Angebote
		panels[0].setBounds(30, 115, 70, 70);
		panels[1].setBounds(117, 115, 70, 70);
		panels[2].setBounds(204, 115, 70, 70);
		panels[3].setBounds(289, 115, 70, 70);
		panels[4].setBounds(30, 200, 70, 70);
		panels[5].setBounds(117, 200, 70, 70);
		panels[6].setBounds(204, 200, 70, 70);
		panels[7].setBounds(289, 200, 70, 70);
		
		//zeitlich begrenzte Angebote
		panels[8].setBounds(29, 320, 330, 110);
		panels[9].setBounds(29, 446, 160, 105);
		panels[10].setBounds(199, 446, 160, 105);
		panels[11].setBounds(29, 565, 330, 170);
		
		for (int i = 0; i < panels.length; i++) {
			buttons[i].setOpaque(false);
			buttons[i].setContentAreaFilled(false);
			buttons[i].setBorderPainted(false);
			
			buttons[i].addActionListener(this);
			
			panels[i].setOpaque(false);
			panels[i].setLayout(new BorderLayout(0, 0));
			
			panels[i].add(buttons[i]);
		}
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * Hintergrundsebene
		 */
		panels[12].setBounds(0, 0, 385, 761); //enspricht 400 und 800 JFrame Pixeln warum auch immer
		panels[12].setLayout(null); //freies Platzieren
						
		labels[0].setBounds(0, 0, 385, 761); //label Gr��e bestimmen
						
		URL image_url = Main.class.getResource("/textures/background/shopbg.png");
						
		BufferedImage image = null;
		try { //Bild Import
			image = ImageIO.read(image_url);
		} catch (IOException e) {
			e.printStackTrace();
		}
						
		Image scaled_image = image.getScaledInstance(labels[0].getWidth(), labels[0].getHeight(), Image.SCALE_REPLICATE); //passt das Bild der Gr��e des JLabels an, "SCALE_REPLICATE" ist die Art wir die Pixel gescaled und Verarbeitet werden
						
		ImageIcon bgimage = new ImageIcon(scaled_image);
						
		labels[0].setIcon(bgimage);
						
		panels[12].add(labels[0]);
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * JPanels werden in diesem Teil mit dem Haupt-JPanel verbunden
		 */
		for (int i = 0; i < panels.length; i++) {
			add(panels[i]);
		}
	}
	
	
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * Actionevents
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		printer_class.actionLog("JButton Event > Shop");
		
		container_class.selectUser(container_class.getCurrentUser()); //w�hlt den aktuellen Benutzer aus dem Tokens genommen werden sollen oder entzogen werden sollen
		
		if (e.getSource() == buttons[0] && container_class.getToken() >= 5) { //Kaffee
			container_class.setToken(-5);
			JOptionPane.showMessageDialog(panels[12], "Kaffee erfolgreich gekauft.\nPreis: 5\nVerbleibender Kontostand: " + container_class.getToken() + ".");
		} else if (e.getSource() == buttons[1] && container_class.getToken() >= 15) { //Croissant
			container_class.setToken(-15);
			JOptionPane.showMessageDialog(panels[12], "Croissant erfolgreich gekauft.\nPreis: 15\nVerbleibender Kontostand: " + container_class.getToken() + ".");
		} else if (e.getSource() == buttons[2] && container_class.getToken() >= 50) { //Schreibblock
			container_class.setToken(-50);
			JOptionPane.showMessageDialog(panels[12], "Schreibblock erfolgreich gekauft.\nPreis: 50\nVerbleibender Kontostand: " + container_class.getToken() + ".");
		} else if (e.getSource() == buttons[3] && container_class.getToken() >= 100) { //Flugzeug
			container_class.setToken(-100);
			JOptionPane.showMessageDialog(panels[12], "Flugzeug erfolgreich gekauft.\nPreis: 100\nVerbleibender Kontostand: " + container_class.getToken() + ".");
		} else if (e.getSource() == buttons[4] && container_class.getToken() >= 10) { //Stift
			container_class.setToken(-10);
			JOptionPane.showMessageDialog(panels[12], "Stift erfolgreich gekauft.\nPreis: 10\nVerbleibender Kontostand: " + container_class.getToken() + ".");
		} else if (e.getSource() == buttons[5] && container_class.getToken() >= 20) { //Br�zel
			container_class.setToken(-20);
			JOptionPane.showMessageDialog(panels[12], "Br�zel erfolgreich gekauft.\nPreis: 20\nVerbleibender Kontostand: " + container_class.getToken() + ".");
		} else if (e.getSource() == buttons[6] && container_class.getToken() >= 80) { //Rolex
			container_class.setToken(-80);
			JOptionPane.showMessageDialog(panels[12], "Rolex erfolgreich gekauft.\nPreis: 80\nVerbleibender Kontostand: " + container_class.getToken() + ".");
		} else if (e.getSource() == buttons[7] && container_class.getToken() >= 200) { //Bagger
			container_class.setToken(-200);
			JOptionPane.showMessageDialog(panels[12], "Bagger erfolgreich gekauft.\nPreis: 200\nVerbleibender Kontostand: " + container_class.getToken() + ".");
		} else if (e.getSource() == buttons[8] && container_class.getToken() >= 50) { //Lamborghini
			container_class.setToken(-50);
			JOptionPane.showMessageDialog(panels[12], "Lamborghini erfolgreich gekauft.\nPreis: 50\nVerbleibender Kontostand: " + container_class.getToken() + ".");
		} else if (e.getSource() == buttons[9] && container_class.getToken() >= 15) { //Snickers
			container_class.setToken(-15);
			JOptionPane.showMessageDialog(panels[12], "Snickers erfolgreich gekauft.\nPreis: 15\nVerbleibender Kontostand: " + container_class.getToken() + ".");
		} else if (e.getSource() == buttons[10] && container_class.getToken() >= 10) { //TikTak
			container_class.setToken(-10);
			JOptionPane.showMessageDialog(panels[12], "TikTak erfolgreich gekauft.\nPreis: 10\nVerbleibender Kontostand: " + container_class.getToken() + ".");
		} else if (e.getSource() == buttons[11] && container_class.getToken() >= 800) { //Megajacht
			container_class.setToken(-800);
			JOptionPane.showMessageDialog(panels[12], "Megajacht erfolgreich gekauft.\nPreis: 800\nVerbleibender Kontostand: " + container_class.getToken() + ".");
		} else { //wenn der Kauf nicht get�tigt werden kann weil man zu wenig Token hat
			printer_class.printLog("Kauf kann nicht fortgesetzt werden da zu wenig Token");
			JOptionPane.showMessageDialog(panels[12], "Du kannst dir diesen Gegenstand nicht leisten.");
		}
	}
}
