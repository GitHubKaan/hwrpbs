package db;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import controller.Printer;
import controller.User;

public class DAOImplementation implements DAO {
	
	static Printer printer_class = new Printer();
	
	@Override
	public void addUser(User user) {
		OracleDsSingleton ora = OracleDsSingleton.getInstance();
		try {
			Connection con = ora.getConnection();
			String sql = "insert into hwrpb values (?, ?, ?)";
			
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, user.getBenutzername());
			ps.setString(2, user.getPasswort());
			ps.setInt(3, user.getTokens());

			ps.executeUpdate();

			printer_class.printLog("DAOImplementation > Benutzer wurde hinzugef�gt");
			
		} catch (SQLException e) {
			printer_class.errLog("Benutzer existiert bereits");
		}

	}
	
	
	
	
	
	@Override
	public void editUser(User user) {
		OracleDsSingleton ora = OracleDsSingleton.getInstance();
		try {
			Connection con = ora.getConnection();
			String sql = ("update hwrpb set token=token+? where benutzername=?");
			
			
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, user.getTokens());
			ps.setString(2, user.getBenutzername());
			ps.executeUpdate();
			
			printer_class.printLog("DAOImplementation > Tokenwert wurde angepasst um: " + user.getTokens());
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	
	
	
	
	@Override
	public void deleteUser(User user) {
		OracleDsSingleton ora = OracleDsSingleton.getInstance();
		try {
			Connection con = ora.getConnection();
			String sql = ("delete from hwrpb where benutzername = ?");
			

			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, user.getBenutzername());

			ps.executeUpdate();
			
			printer_class.printLog("DAOImplementation > Benutzer wurde gel�scht");
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	
	static int currentToken;
	static String currentUsername;
	static String currentPassword;
	@Override
	public boolean getUser(User user) {
		OracleDsSingleton ora = OracleDsSingleton.getInstance();
		try {
			Connection con = ora.getConnection();
			Statement stmt = con.createStatement();
			String addQuery = "select * from hwrpb where benutzername = '" + user.getBenutzername() + "' and passwort = '" + user.getPasswort() + "'";
			ResultSet rs = stmt.executeQuery(addQuery);
			
			currentUsername = user.getBenutzername();
			currentPassword = user.getPasswort();
			
			while (rs.next()) {
				
				try {
					User user_class = new User();
					user_class.setTokens(rs.getInt("token"));
					
					currentToken = user_class.getTokens();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;

	}
	
	public int getCurrentTokens() {
		return currentToken;
	}
	
	public String getCurrentUsername() {
		return currentUsername;
	}
	
	public String getCurrentPassword() {
		return currentPassword;
	}
	
	// delete statement
	// delete from hwrpb where benutzername = 'test'
}
