package db;

import java.sql.*;
import oracle.jdbc.pool.OracleDataSource;

public class OracleDsSingleton {
	
	private static OracleDsSingleton dss = null;
	private static OracleDataSource ds = null;
	
	
	private OracleDsSingleton(){
		
		try {
			ds = new OracleDataSource();
			
			ds.setDataSourceName("");
			ds.setURL("");
			
			ds.setUser("");
			ds.setPassword("");
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	
	public static OracleDsSingleton getInstance() {
		if(dss == null) dss = new OracleDsSingleton();
		return dss;
	}
	
	public Connection getConnection() throws SQLException{
		Connection con = null;
		con = ds.getConnection();
		return con;
	}
}
