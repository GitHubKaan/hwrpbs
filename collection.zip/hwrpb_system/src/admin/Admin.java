package admin;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.URL;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import controller.User;
import db.DAOImplementation;
import controller.Fonts;
import controller.Printer;

public class Admin implements ActionListener {
	
	static int adminwindow = 1; // 0 = inaktiv, 1 = aktiv

	
	// []--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * Positionierung
	 * 
	 * Positionsierung:
	 * panel 0 - Dropdown Men� (Accountname)
	 * panel 1 - +1 Token
	 * panel 2 - +5 Token
	 * panel 3 - +10 Token
	 * panel 4 - -1 Token
	 * panel 5 - -5 Token
	 * panel 6 - -10 Token
	 * panel 7 - Benutzer l�schen
	 * panel 8 - Benutzer hinzuf�gen
	 * panel 9 - Benutzername hinzuf�gen
	 * panel 10 - Passwort hinzuf�gen
	 * panel 11 - Token hinzuf�gen
	 */
	
	JPanel[] panels = new JPanel[100];
	JButton[] buttons = new JButton[100];
	JTextField[] textfields = new JTextField[100];

	
	User user_class = new User();
	Printer printer_class = new Printer();
	Fonts fonts_class = new Fonts();

	
	public Admin() throws IOException {
		printer_class.printLog(Admin.class + " -> abruf");

		
		for (int i = 0; i < 100; i++) {
			panels[i] = new JPanel();
			buttons[i] = new JButton();
			textfields[i] = new JTextField();
		}

		
		JFrame frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(225, 230);
		frame.setLocation(400, 400);
		frame.setTitle("admin");
		frame.setLayout(null);
		frame.setResizable(false);
		frame.getContentPane().setBackground(Color.DARK_GRAY);

		
		URL icon_image_url = getClass().getResource("/textures/extra/icon2.png");
		ImageIcon icon = new ImageIcon(icon_image_url);
		frame.setIconImage(icon.getImage());

		
		for (int i = 0; i < panels.length; i++) {
			panels[i].setOpaque(false);
			panels[i].setLayout(new BorderLayout(0, 0));
		}
		
		
		textfields[3].setFont(fonts_class.getFontTypeA());
		
		panels[0].setBounds(0, 0, 210, 20);
		panels[0].add(textfields[3]);
		
		
		buttons[0].setText("+1");
		panels[1].setBounds(0, 20, 70, 30);
		buttons[1].setText("+10");
		panels[2].setBounds(70, 20, 70, 30);
		buttons[2].setText("+100");
		panels[3].setBounds(140, 20, 70, 30);
		buttons[3].setText("-1");
		panels[4].setBounds(0, 50, 70, 30);
		buttons[4].setText("-10");
		panels[5].setBounds(70, 50, 70, 30);
		buttons[5].setText("-100");
		panels[6].setBounds(140, 50, 70, 30);
		buttons[6].setText("Konto l�schen");
		panels[7].setBounds(0, 80, 210, 30);
		buttons[7].setText("Konto hinzuf�gen (B, P, T)");
		panels[8].setBounds(0, 160, 210, 30);

		for (int i = 0; i < 8; i++) {
			panels[i + 1].add(buttons[i]);
		}
		
		
		panels[9].setBounds(0, 130, 70, 30);
		panels[10].setBounds(70, 130, 70, 30);
		panels[11].setBounds(140, 130, 70, 30);
		
		for (int i = 0; i < 3; i++) {
			panels[i + 9].add(textfields[i]);
		}
		
		
		for (int i = 0; i < buttons.length; i++) {
			buttons[i].addActionListener(this);
			
			frame.add(panels[i]);
		}
		
		
		if (adminwindow == 1) {
			frame.setVisible(true);
		}
	}

	
	public void actionPerformed(ActionEvent e) {
		printer_class.actionLog("JButton Action > Admin");
		
		
		DAOImplementation dao = new DAOImplementation();
		
		
		//Konto L�schen
		if (e.getSource() == buttons[6] && !textfields[3].getText().isEmpty()) {
			User deleteUser = new User(textfields[3].getText(), "", 0);
		
			dao.deleteUser(deleteUser);
				
			textfields[3].setText("");
		}
		
		
		
		//Konto-Erstellen Action
		if (e.getSource() == buttons[7]) {
			if (textfields[0].getText().length() > 50 || textfields[1].getText().length() > 50 || textfields[2].getText().length() > 9) { //wenn Eingaben zu gro� sind
				printer_class.errLog("Eingabe zu gro�, bitte w�hle kleinere Eingabewerte (Passwort/Benutzername: max 50, Token: max 9)");
			} else {
				String benutzername = textfields[0].getText();
				String passwort = textfields[1].getText();
				
				boolean match = textfields[2].getText().matches("[0-9]+"); //Wenn beim Token Feld keine Zahlen eingegeben wurden sind
				if (match == true) {
					
					int token = (int) Integer.parseInt(textfields[2].getText());
					
					User User = new User(benutzername, passwort, token);
					
					if (dao.getUser(User) == false && !textfields[0].getText().isEmpty() && !textfields[1].getText().isEmpty()) { //Kontrolle erfolgt hier
						dao.addUser(User);
						
						for (int i = 0; i < 3; i++) {
							textfields[i].setText("");
						}
					} else {
						printer_class.errLog("Fehlerhafte Eingabe");
					}
				} else {
					printer_class.errLog("Falsche Formatierung im Token-Feld");
				}
			}
		}
		
		
		
		
		//Tokens geben/nehmen
		for (int i = 0; i < 6; i++) {
			if (e.getSource() == buttons[i] && !textfields[3].getText().isEmpty()) {
				User tokenUser = new User(textfields[3].getText(), "", Integer.parseInt(buttons[i].getText()));
				dao.editUser(tokenUser);
			}
		}
	}
}
