package ui;

import java.awt.BorderLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import controller.User;
import db.DAOImplementation;
import controller.Fonts;
import controller.Frame;
import controller.Main;
import controller.Printer;

public class Home implements ActionListener {
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * Positionierung
	 * 
	 * Positionsierung:
	 * 		panel 0 - Hintergrundsebene
	 * 		panel 1 - Einstellungen
	 * 		panel 2 - Nachricht
	 * 		panel 3 - Shop
	 * 		panel 4 - Anleitung
	 *		panel 5 - Zur�ck
	 *		panel 6 - Token Anzeige
	 */
	static JPanel[] panels = new JPanel[100];
	static JLabel[] labels = new JLabel[100]; 
	static JButton[] buttons = new JButton[100];
	
	
	User user_class = new User();
	Settings settings_class = new Settings();
	Help help_class = new Help();
	Shop shop_class = new Shop();
	Printer printer_class = new Printer();
	Frame frame_class = new Frame();
	Fonts fonts_class = new Fonts();
	DAOImplementation dao_class = new DAOImplementation();
	
	
	public Home() throws IOException {
		printer_class.printLog(Home.class + " -> abruf");
		
		
		for (int i = 0; i < 100; i++) {
		    panels[i] = new JPanel();
			labels[i] = new JLabel();
			buttons[i] = new JButton();
		}
		
		
		JFrame frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(400, 800);
		frame.setTitle("hwrpb_system - home ui");
		frame.setResizable(false);
		frame.setLocation(frame_class.getLastFrameLocation()); //Platziert den Home-JFrame dort hin wo der Login-JFrame zuletzt war
		
		URL icon_image_url = getClass().getResource("/textures/extra/icon.png");
		ImageIcon icon = new ImageIcon(icon_image_url);
		frame.setIconImage(icon.getImage());
		
		
		frame.add(settings_class);
		frame.add(help_class);
		frame.add(shop_class);
		
		
		for (int i = 0; i < panels.length; i++) { //JPanels unsichtbar machen
		    panels[i].setOpaque(false);
		    panels[i].setLayout(new BorderLayout(0, 0)); //Funktioniert wie ".pack" damit die Objekte sich an die Gr��e des "panels" anpassen
		}
		
		
		panels[1].setBounds(350, 5, 30, 30);
		panels[2].setBounds(30, 134, 385, 79);
		panels[3].setBounds(0, 227, 385, 168);
		panels[4].setBounds(0, 407, 385, 168);
		panels[5].setBounds(10, 10, 35, 35);
		
		for (int i = 1; i < 6; i++) {
			if (i != 2) {
				panels[i].add(buttons[i - 1]); //-1 weil die Schleife bei eins startet
			}
		}
		
		for (int i = 0; i < buttons.length; i++) {
			buttons[i].setOpaque(false);
			buttons[i].setContentAreaFilled(false);
			buttons[i].setBorderPainted(false);
			
			buttons[i].addActionListener(this);
		}
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * Token Anzeige
		 */
		labels[1].setFont(fonts_class.getFontTypeB());
		
		validateToken(); //Kontostand Abfragen/erneuern
		
		panels[6].setBounds(87, 62, 288, 30);
		panels[6].add(labels[1]);
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * Nachricht
		 */
		labels[2].setFont(fonts_class.getFontTypeC());
		
		labels[2].setText("<html>Willkommen zur�ck " + dao_class.getCurrentUsername().substring(0, 1).toUpperCase() + dao_class.getCurrentUsername().substring(1) + ".</html>");
		
		panels[2].add(labels[2]);
		
		
		
		for (int i = 0; i < panels.length; i++) {
			frame.add(panels[i]);
		}
		
		
		
		labels[0].setBounds(0, 0, 385, 761); //label Gr��e bestimmen
		
		URL image_url = Main.class.getResource("/textures/background/homebg.png");
		
		BufferedImage image = null;
		try { //Bild Import
			image = ImageIO.read(image_url);
		} catch (IOException e) {
			e.printStackTrace();
		}
				
		Image scaled_image = image.getScaledInstance(labels[0].getWidth(), labels[0].getHeight(), Image.SCALE_REPLICATE); //passt das Bild der Gr��e des JLabels an, "SCALE_REPLICATE" ist die Art wir die Pixel gescaled und verarbeitet werden
				
		ImageIcon bgimage = new ImageIcon(scaled_image);
				
		labels[0].setIcon(bgimage);
		labels[0].setBounds(0, 0, 385, 761);
				
		frame.add(labels[0]);
		
		
		
		frame.setVisible(true);
		
		
		
		settings_class.buttons[1].addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				
				frame.setVisible(false);
				
				frame_class.setFrameLocation(frame.getLocation());
				
				try {
					new Login();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				
				printer_class.actionLog("JButton Event > Settings");
				
				printer_class.printLog("Benutzer wird abgemeldet...");
			}
		});
	}
	
	
	public void actionPerformed(ActionEvent e) {
		printer_class.actionLog("JButton Event > Home");
		
		if (e.getSource() == buttons[0]) { //Einstellungen
			settings_class.setVisible(true);
			homeClose();
		}
		
		if (e.getSource() == buttons[2]) { //Shop
			shop_class.setVisible(true);
			homeClose();
		}
		
		if (e.getSource() == buttons[3]) { //Hilfe
			help_class.setVisible(true);;
			homeClose();
		}
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * Actionevents die von anderen Klassen ausgef�hrt werden k�nnen
		 */
		if (e.getSource() == buttons[4]) { //Zur�ck JButton schaltet wieder auf die Home-Klasse zur�ck
			settings_class.setVisible(false);
			help_class.setVisible(false);
			shop_class.setVisible(false);
			
			validateToken();
			
			homeOpen();
		}
	}
	
	
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * Aktivierungs und Deaktivierungs Optionen bei Verlassen der Home-Klasse
	 */
	private void homeOpen() {
		for (int i = 0; i < buttons.length; i++) {
			buttons[i].setVisible(true);
		}
	}
	
	private void homeClose() {
		for (int i = 0; i < buttons.length; i++) {
			if (i != 4) { //weil der vierte Button zum Zur�ckgehen gedacht ist
				buttons[i].setVisible(false);
			}
		}
	}
	
	
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * Ausgabeeinstellungen der Token Anzeige
	 */
	private void validateToken() {
		User currentUser = new User(dao_class.getCurrentUsername(), dao_class.getCurrentPassword(), 0); //aktuallisierung der aktuellen Benutzerdaten
		dao_class.getUser(currentUser);
		
		Integer currentTokens = dao_class.getCurrentTokens();

		
		if (currentTokens == 0) {
			labels[1].setText("Du hast keine Token");
		} else if (currentTokens > 0) {
			labels[1].setText(currentTokens.toString() + " Token");
		} else {
			labels[1].setText("FEHLER");
		}
	}
}
