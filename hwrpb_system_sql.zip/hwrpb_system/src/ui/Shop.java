package ui;

import java.awt.BorderLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import controller.User;
import db.DAOImplementation;
import controller.Main;
import controller.Printer;

public class Shop extends JPanel implements ActionListener {
	JPanel[] panels = new JPanel[100];
	JButton[] buttons = new JButton[100];
	JLabel[] labels = new JLabel[100];
	
	
	User user_class = new User();
	Printer printer_class = new Printer();
	DAOImplementation dao_class = new DAOImplementation();
	
	public Shop() throws IOException {
		printer_class.printLog(Shop.class + " -> abruf");
		
		
		for (int i = 0; i < 100; i++) {
		    panels[i] = new JPanel();
		    buttons[i] = new JButton();
			labels[i] = new JLabel();
		}
		
		
		setBounds(0, 0, 400, 800);
		setVisible(false);
		setLayout(null);
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * JButtons zum kaufen eines Produktes
		 */
		//aktuelle Angebote
		panels[0].setBounds(30, 115, 70, 70);
		panels[1].setBounds(117, 115, 70, 70);
		panels[2].setBounds(204, 115, 70, 70);
		panels[3].setBounds(289, 115, 70, 70);
		panels[4].setBounds(30, 200, 70, 70);
		panels[5].setBounds(117, 200, 70, 70);
		panels[6].setBounds(204, 200, 70, 70);
		panels[7].setBounds(289, 200, 70, 70);
		
		//zeitlich begrenzte Angebote
		panels[8].setBounds(29, 320, 330, 110);
		panels[9].setBounds(29, 446, 160, 105);
		panels[10].setBounds(199, 446, 160, 105);
		panels[11].setBounds(29, 565, 330, 170);
		
		for (int i = 0; i < panels.length; i++) {
			buttons[i].setOpaque(false);
			buttons[i].setContentAreaFilled(false);
			buttons[i].setBorderPainted(false);
			
			buttons[i].addActionListener(this);
			
			panels[i].setOpaque(false);
			panels[i].setLayout(new BorderLayout(0, 0));
			
			panels[i].add(buttons[i]);
		}
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * Hintergrundsebene
		 */
		panels[12].setBounds(0, 0, 385, 761); //enspricht 400 und 800 JFrame Pixeln warum auch immer
		panels[12].setLayout(null); //freies Platzieren
						
		labels[0].setBounds(0, 0, 385, 761); //label Gr��e bestimmen
						
		URL image_url = Main.class.getResource("/textures/background/shopbg.png");
						
		BufferedImage image = null;
		try {
			image = ImageIO.read(image_url);
		} catch (IOException e) {
			e.printStackTrace();
		}
						
		Image scaled_image = image.getScaledInstance(labels[0].getWidth(), labels[0].getHeight(), Image.SCALE_REPLICATE); //passt das Bild der Gr��e des JLabels an, "SCALE_REPLICATE" ist die Art wir die Pixel gescaled und Verarbeitet werden
						
		ImageIcon bgimage = new ImageIcon(scaled_image);
						
		labels[0].setIcon(bgimage);
						
		panels[12].add(labels[0]);
		
		
		
		for (int i = 0; i < panels.length; i++) {
			add(panels[i]);
		}
	}


	
	
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * Actionevents
	 */

	@Override
	public void actionPerformed(ActionEvent e) {
		printer_class.actionLog("JButton Event > Shop");
		
		int price = 0;
		
		
		if (e.getSource() == buttons[0] && dao_class.getCurrentTokens() >= 5) { //Kaffee
			price = -5;
			
		} else if (e.getSource() == buttons[1] && dao_class.getCurrentTokens() >= 15) { //Croissant
			price = -15;
			
		} else if (e.getSource() == buttons[2] && dao_class.getCurrentTokens() >= 50) { //Schreibblock
			price = -50;
			
		} else if (e.getSource() == buttons[3] && dao_class.getCurrentTokens() >= 100) { //Flugzeug
			price = -100;
			
		} else if (e.getSource() == buttons[4] && dao_class.getCurrentTokens() >= 10) { //Stift
			price = -10;
			
		} else if (e.getSource() == buttons[5] && dao_class.getCurrentTokens() >= 20) { //Br�zel
			price = -20;
			
		} else if (e.getSource() == buttons[6] && dao_class.getCurrentTokens() >= 80) { //Rolex
			price = -80;
			
		} else if (e.getSource() == buttons[7] && dao_class.getCurrentTokens() >= 200) { //Bagger
			price = -200;
			
		} else if (e.getSource() == buttons[8] && dao_class.getCurrentTokens() >= 50) { //Lamborghini
			price = -50;
			
		} else if (e.getSource() == buttons[9] && dao_class.getCurrentTokens() >= 15) { //Snickers
			price = -15;
			
		} else if (e.getSource() == buttons[10] && dao_class.getCurrentTokens() >= 10) { //TikTak
			price = -10;
			
		} else if (e.getSource() == buttons[11] && dao_class.getCurrentTokens() >= 800) { //Megajacht
			price = -800;
			
		} else { //wenn der Kauf nicht get�tigt werden kann weil man zu wenig Token hat
			printer_class.printLog("Kauf kann nicht fortgesetzt werden da zu wenig Token");
			JOptionPane.showMessageDialog(panels[12], "Du kannst dir diesen Gegenstand nicht leisten.");
		}
		
		
		if (price < 0) { //wenn etwas gekauft wurde
			User currentUser = new User(dao_class.getCurrentUsername(), dao_class.getCurrentPassword(), 0); //refresh user data
			dao_class.getUser(currentUser);
				
			User tokenUser = new User(dao_class.getCurrentUsername(), "", price);
			dao_class.editUser(tokenUser);
					
			JOptionPane.showMessageDialog(panels[12], "Kauf erfolgreich.\nPreis: " + Math.abs(price) /*Macht negativ positiv*/ + "\nVerbleibender Kontostand: " + (dao_class.getCurrentTokens() + price) + ".");
			
			price = 0;
		}
	}
	
}
