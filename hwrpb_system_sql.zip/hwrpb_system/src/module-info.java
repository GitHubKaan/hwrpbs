module hwrpb_system {
	requires java.desktop;
	requires ojdbc7;
	requires java.sql;
}