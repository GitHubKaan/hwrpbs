package controller;

import java.io.IOException;

public class User {
	
	String benutzername;
	String passwort;
	int tokens;
	
	static Printer printer_class = new Printer();
	
	
	public User() throws IOException {
		printer_class.printLog(User.class + " -> abruf");
	}
	
	public User(String benutzername, String passwort, int tokens) {
		
		this.benutzername = benutzername;
		this.passwort = passwort;
		this.tokens = tokens;
	}
	
	public String getBenutzername() {
		return benutzername;
	}


	public void setBenutzername(String benutzername) { //reg
		this.benutzername = benutzername;
	}


	public String getPasswort() {
		return passwort;
	}


	public void setPasswort(String passwort) {
		this.passwort = passwort;
	}


	public int getTokens() {
		return tokens;
	}


	public void setTokens(int t) {
		this.tokens = t;
	}
}
