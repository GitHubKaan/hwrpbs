package controller;

import java.awt.Point;
import java.io.IOException;

public class Frame {
	
	Printer printer_class = new Printer();
	
	public Frame() throws IOException {
		printer_class.printLog(Frame.class + " -> abruf");
	}
	
	
	static Point frame_location;
		
	public void setFrameLocation(Point l) {
		frame_location = l;
	}
	
	public Point getLastFrameLocation() {
		return frame_location;
	}
}
