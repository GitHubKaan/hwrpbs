package db;

import controller.User;

public interface DAO {
	public void addUser(User user);
	public void editUser(User user);
	public void deleteUser(User user);
	public boolean getUser(User user);
	
}
